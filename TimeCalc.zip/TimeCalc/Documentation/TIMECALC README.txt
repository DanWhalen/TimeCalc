TimeCalc by Dan Whalen

Copyright 2014

(Python 2.7 script, made executable with Py2Exe)

danpwhalen@gmail.com

-----------------------------------------------------------


Please read "TimeCalc - User's Guide" before using TimeCalc.

To begin, open file called 'TIMECALC.EXE', located in the 'Program' folder.



